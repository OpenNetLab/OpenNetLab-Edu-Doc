from onl.sim import Environment
from onl.netdev import Wire, Cable
from framegenerator import FrameGenerator
from endpoint import Endpoint
from switch import Switch

env = Environment()

receiver_num = 4
mac_addrs = [
    "6b:2a:f5:d6:c3:49",
    "7a:98:8f:a9:9c:72",
    "4d:4a:5d:3d:bf:eb",
    "f8:ba:7b:ae:f1:b4",
]

frames = [
    "6b:2a:f5:d6:c3:49",
    "6b:2a:f5:d6:c3:49",
    "7a:98:8f:a9:9c:72",
    "4d:4a:5d:3d:bf:eb",
    "f8:ba:7b:ae:f1:b4",
    "f8:ba:7b:ae:f1:b4",
    "7a:98:8f:a9:9c:72",
    "4d:4a:5d:3d:bf:eb",
    "6b:2a:f5:d6:c3:49",
]

expected_res = [
    1, 2, 3, 4, 
    1, 
    1, 2, 3, 4,
    1, 2, 3, 4, 
    1, 2, 3, 4, 
    4, 
    2, 
    3, 
    1
    ]

assert len(mac_addrs) == receiver_num
receivers = [Endpoint(env, mac_addr, debug=True) for mac_addr in mac_addrs]
switch = Switch(env, receiver_num + 1, debug=True)
#交换机共有receiver_num+1个端口，其中第一个端口连接framegenerator，其余端口连接receiver
wire = Wire(env, delay_dist=lambda: 10)
cables = [Cable(env, delay_dist=lambda: 10) for _ in range(receiver_num)]
frame_generator = FrameGenerator(env, frames, debug=True)

frame_generator.out = wire
wire.out = switch.ports[0]
for i in range(receiver_num):
    cables[i].set_endpoints(switch.ports[i + 1], receivers[i])

env.run(frame_generator.proc)

print(switch.log == expected_res)
