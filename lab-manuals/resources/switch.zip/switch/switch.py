from onl.sim import Environment
from onl.device import Device, SingleDevice
from onl.sim import Environment
from framegenerator import FrameType, Frame


class SwitchPort(SingleDevice):
    def __init__(self, switch: "Switch", port_num: int):
        self.port_num = port_num
        self.switch = switch
        self.out = None

    def send(self, frame: Frame):
        self.out.put(frame)

    def put(self, frame: Frame):
        self.switch.recv(frame, self.port_num)


class Switch(Device):
    def __init__(self, env: Environment, port_num: int, debug: bool = False):
        self.env = env
        self.receiver_num = port_num
        self.ports = [SwitchPort(self, i) for i in range(port_num)]
        self.log = []
        self.debug = debug
        # self.forward_table
        """
        TODO:根据实际需求,实现交换机的转发表,要求至少包含mac地址和对应的端口号
        """

    def forward(self, port_num: int, frame: Frame):
        self.log.append(port_num)
        self.ports[port_num].send(frame)

    def recv(self, frame: Frame, port_num: int):
        """
        TODO:根据接收帧的frame_type进行相应的处理
        1. 如果frame_type为DATA
            1.1mac地址在转发表中，转发数据帧到对应端口
            1.2mac地址不在转发表中，广播数据帧到所有端口(framegenerator所在的端口0不需要转发)
        2. 如果frame_type为ACK
            2.1添加转发表项
        """

    def dprint(self, s: str):
        if self.debug:
            print(f"[switch](time: {self.env.now:.2f})", end=" -> ")
            print(s)
