from typing import Deque
from dataclasses import dataclass
from collections import deque
from onl.packet import Packet
from onl.device import SingleDevice
from onl.sim import Environment, Store
from onl.utils import Timer


@dataclass
class QueueItem:
    packet: Packet
    ack_received: bool = False


class SRSender(SingleDevice):
    def __init__(
        self,
        env: Environment,
        seqno_width: int,
        timeout: float,
        window_size: int,
        message: str,
        debug: bool = False,
    ):
        self.env = env
        # the bits of the sequence number, which decides the sequence
        # number range and window size of selective repeat
        self.seqno_width = seqno_width
        self.seqno_range = 2**self.seqno_width
        self.window_size = window_size
        assert self.window_size <= self.seqno_range // 2
        # time interval for timeout resending
        self.timeout = timeout
        self.debug = debug
        self.message = message
        # the sequence number of the next character to be sent
        self.seqno = 0
        # the absolute index of the next character to be sent
        self.absno = 0
        # sequence number of first packet in outbound buffer
        self.seqno_start = 0
        # packet buffer to save the packets that havn't been acknowledged by receiver
        self.outbound: Deque[QueueItem] = deque()
        self.timers: Deque[Timer] = deque()
        # use `self.finish_channel.put(True)` to termiate the sending process
        self.finish_channel: Store = Store(env)

        self.proc = env.process(self.run(env))

    def new_packet(self, seqno: int, data: str) -> Packet:
        return Packet(time=self.env.now, size=40, packet_id=seqno, payload=data)

    def send_available(self):
        """
        TODO:
        1.当收到接收方的确认后，判断该确认是否合法
            1.1若合法的话，将对应缓冲区中的帧标记为被确认，
            如果被确认的帧位于滑动窗口头部，移动滑动窗口直到头部的帧未被确认，并且发送接下来可以发送的帧；
            1.2若不合法，不做任何处理
        2.每发送一个帧时，保存该帧在缓冲区中
        3.每个缓冲区内的帧对应一个定时器，当定时器超时的时候，重新发送对应的帧
        """

    def timeout_callback(self, packet: Packet):
        self.dprint("timeout")
        self.send_packet(packet)

    def send_packet(self, packet: Packet):
        """Timeout callback for timer"""
        self.dprint(f"send {packet.payload} on seqno {packet.packet_id}")
        assert self.out
        """Call Wire's put method to implement packet scheduling"""
        self.out.put(packet)

    def run(self, env: Environment):
        self.send_available()
        yield self.finish_channel.get()

    def put(self, packet: Packet):
        """Receiving acknowledgement packet from receiver"""
        """
        TODO:
        1.检查收到的ACK是否合法，若合法，将对应缓冲区中的帧标记为被确认,并进行send_available
        2.检查是否所有帧都已发送并确认，若是，self.finish_channel.put(True)，表示结束
        """

        ackno = packet.packet_id

    def dprint(self, s):
        if self.debug:
            print(f"[sender](time: {self.env.now:.2f})", end=" -> ")
            print(s)
