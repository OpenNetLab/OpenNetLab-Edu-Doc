from onl.sim import Environment
from onl.device import Device, SingleDevice
from onl.sim import Environment
from onl.utils import Timer
from onl.packet import Packet


class SwitchPort(SingleDevice):
    def __init__(self, switch: "Switch", port_id: int):
        self.port_id = port_id
        self.switch = switch
        self.out = None

    def send(self, packet: Packet):
        self.out.put(packet)

    def put(self, packet: Packet):
        self.switch.recv(packet, self.port_id)


class Switch(Device):
    def __init__(self, env: Environment, ports_num: int, debug: bool = False):
        self.env = env
        self.ports_num = ports_num
        self.ports = [SwitchPort(self, i) for i in range(ports_num)]
        # self.forward_table
        """
        TODO:根据实际需要设计转发表，要求表项包含TTL字段，用于记录表项的超时时间
        """
        self.log = []
        self.debug = debug
        self.timeout = 200

    def forward(self, port_id: int, packet: Packet):
        self.log.append(port_id)
        self.ports[port_id].send(packet)

    def recv(self, packet: Packet, port_in: int):
        """
        TODO:实现交换机接收到帧后的处理逻辑
        1.在交换机表中添加（或刷新）发送者的MAC地址和收到该帧接口的表项
        2.使用该帧的目的MAC地址在转发中检索
        3.如果存在该地址的表项
            3.1如果表项的接口是收到帧的接口，丢弃该帧，不转发
            3.2否则，按表项中的接口转发帧
        4.如果不存在该地址的表项，则泛洪，即将该帧从除了到达接口外的所有接口转发
        注：表项中的TTL可用定时器Timer实现，使用格式如下：
        timer = Timer(
            self.env,
            self.timeout,
            self.timeout_callback,
            auto_restart=True,
            args=[mac_addr], # 可将MAC地址作为回调函数的参数，超时时删除对应MAC地址的表项
        )
        """

    def timeout_callback(self, mac_addr: str):
        """
        TODO:根据你设计的转发表，删除超时的表项
        1.先暂停该表项的定时器,即调用timer.stop()
        2.删除该表项
        """

    def dprint(self, s: str):
        if self.debug:
            print(f"[switch](time: {self.env.now:.2f})", end=" -> ")
            print(s)
