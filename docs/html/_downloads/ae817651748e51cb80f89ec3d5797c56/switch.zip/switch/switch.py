from onl.sim import Environment
from onl.device import Device
from onl.sim import Environment
from typing import List
from framegenerator import FrameType, Frame


class Switch(Device):
    def __init__(self, env: Environment, outs: List[Device], debug: bool = False):
        self.env = env
        self.outs = outs
        self.debug = debug
        self.log = []
        # self.forward_table
        """
        TODO:根据实际需求,实现交换机的转发表,要求至少包含mac地址和对应的端口号
        """

    def forward(self, port_num: int, frame: Frame):
        self.log.append(port_num)
        self.outs[port_num].put(frame)

    def put(self, frame: Frame):
        """
        TODO:根据接收帧的frame_type进行相应的处理
        1. 如果frame_type为DATA
            1.1mac地址在转发表中，转发数据帧到对应端口
            1.2mac地址不在转发表中，广播数据帧到所有端口
        2. 如果frame_type为ACK
            2.1添加转发表项
        提示:数据帧的格式参见framegenerator.py中的Frame类,你可能会利用到数据帧中的信息
        """

    def dprint(self, s: str):
        if self.debug:
            print(f"[switch](time: {self.env.now:.2f})", end=" -> ")
            print(s)
