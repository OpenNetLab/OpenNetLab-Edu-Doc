from onl.sim import Environment
from onl.device import SingleDevice
from onl.sim import Environment

from framegenerator import FrameType, Frame


class Endpoint(SingleDevice):
    def __init__(self, env: Environment, mac_addr: str,debug: bool = False):
        self.env = env
        self.mac_addr = mac_addr
        self.debug = debug  

    def put(self, frame: Frame):
        if frame.frame_type == FrameType.DATA:
            self.dprint(f"received data frame {frame.packet_id}")
        elif frame.frame_type == FrameType.BROADCAST:
            if frame.mac_addr == self.mac_addr:
                new_frame = Frame(self.env.now,40,frame.packet_id,self.mac_addr,FrameType.ACK)
                assert self.out
                self.out.put(new_frame)
                self.dprint(f"received broadcast frame and send ack")
            else:
                self.dprint(f"received broadcast frame")

    def dprint(self, s: str):
        if self.debug:
            print(f"[endpoints:{self.mac_addr}](time: {self.env.now:.2f})", end=" -> ")
            print(s)