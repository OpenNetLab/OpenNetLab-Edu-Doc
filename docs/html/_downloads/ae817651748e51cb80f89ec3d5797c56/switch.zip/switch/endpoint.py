from onl.sim import Environment
from onl.device import SingleDevice
from onl.sim import Environment

from framegenerator import FrameType, Frame


class Endpoint(SingleDevice):
    def __init__(self, env: Environment, mac_addr: str, debug: bool = False):
        self.env = env
        self.mac_addr = mac_addr
        self.debug = debug

    def put(self, frame: Frame):
        """
        TODO:根据接收帧的frame_type进行相应的处理
        1. 如果frame_type为DATA,打印收到的数据帧Id
        2. 如果frame_type为BROADCAST
            2.1如果mac地址与自身mac地址相同,发送ACK帧(包含自身的mac地址)给交换机
            2.2否则不做处理
        """

    def dprint(self, s: str):
        if self.debug:
            print(f"[endpoints:{self.mac_addr}](time: {self.env.now:.2f})", end=" -> ")
            print(s)
