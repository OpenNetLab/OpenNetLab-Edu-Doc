from onl.sim import Environment
from onl.device import SingleDevice
from onl.packet import Packet
from onl.sim import Environment
from enum import Enum
from typing import List
import random

class FrameType(Enum):
    DATA = 0
    BROADCAST = 1
    ACK = 2

class Frame(Packet):
    def __init__(
        self,
        time: float,
        size: int,
        id: int,
        mac_addr: str,
        frame_type: FrameType,
    ):
        self.packet_id = id
        super().__init__(
            time, size, id, payload={"mac_addr": mac_addr, "frame_type": frame_type}
        )

    @property
    def mac_addr(self):
        return self.payload["mac_addr"]

    @property
    def frame_type(self):
        return self.payload["frame_type"]

class FrameGenerator(SingleDevice):
    def __init__(
        self,
        env: Environment,
        frames: List[Frame],
        debug: bool = False,
    ):
        self.env = env
        self.frames = frames
        self.proc=env.process(self.run(env))
        self.debug = debug

    def run(self,env:Environment):
        for id,frame in  enumerate(self.frames):
            size=random.randint(40,100)
            new_frame=Frame(self.env.now,size,id,frame,FrameType.DATA)
            self.out.put(new_frame)
            self.dprint(f"generate data frame {new_frame.packet_id} to {new_frame.mac_addr}")
            # 间隔50个时间单位，以备交换机完成自学习
            yield env.timeout(50)

    def put(self):
        pass

    def dprint(self, s: str):
        if self.debug:
            print(f"[framegenerator](time: {self.env.now:.2f})", end=" -> ")
            print(s)
