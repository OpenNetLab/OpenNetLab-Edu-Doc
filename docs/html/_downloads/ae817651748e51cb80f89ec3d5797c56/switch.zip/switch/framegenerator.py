from onl.sim import Environment
from onl.device import SingleDevice
from onl.packet import Packet
from onl.sim import Environment
from enum import Enum
from typing import List
import random


class SendPort(SingleDevice):
    def __init__(self, sender: "FrameGenerator", port_id: int):
        self.port_id = port_id
        self.sender = sender
        self.out = None

    def send(self, frame: Packet):
        self.out.put(frame)

    def put(self, frame: Packet):
        self.sender.recv(frame, self.port_id)


class FrameGenerator(SingleDevice):
    def __init__(
        self,
        env: Environment,
        frames: List[Packet],
        ports_num: int,
        debug: bool = False,
    ):
        self.env = env
        self.frames = frames
        self.ports = [SendPort(self, i) for i in range(ports_num)]
        self.proc = env.process(self.run(env))
        self.debug = debug

    def run(self, env: Environment):
        for id, frame in enumerate(self.frames):
            size = random.randint(64, 1518)
            new_frame = Packet(self.env.now, size, id, src=frame[0], dst=frame[1])
            port = frame[2]
            self.ports[port].send(new_frame)
            self.dprint(
                f"send frame from {new_frame.src} to {new_frame.dst} on port {port}"
            )
            # 间隔50个时间单位，以备交换机完成自学习
            yield env.timeout(50)

    def recv(self, frame: Packet, port_id: int):
        pass

    def put(self):
        pass

    def dprint(self, s: str):
        if self.debug:
            print(f"[framegenerator](time: {self.env.now:.2f})", end=" -> ")
            print(s)
