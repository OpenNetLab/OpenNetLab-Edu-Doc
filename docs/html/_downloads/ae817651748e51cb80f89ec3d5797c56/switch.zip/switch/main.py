from onl.sim import Environment
from onl.netdev import Wire, Cable
from framegenerator import FrameGenerator
from switch import Switch

env = Environment()

ports_num = 4
mac_addrs = [
    "6b:2a:f5:d6:c3:49",
    "7a:98:8f:a9:9c:72",
    "4d:4a:5d:3d:bf:eb",
    "f8:ba:7b:ae:f1:b4",
]

#[src, dst, port]
frames = [
    ["6b:2a:f5:d6:c3:49", "7a:98:8f:a9:9c:72", 0],
    ["7a:98:8f:a9:9c:72", "4d:4a:5d:3d:bf:eb", 1],
    ["4d:4a:5d:3d:bf:eb", "7a:98:8f:a9:9c:72", 3],
    ["6b:2a:f5:d6:c3:49", "4d:4a:5d:3d:bf:eb", 2],
    ["6b:2a:f5:d6:c3:49", "7a:98:8f:a9:9c:72", 2],
    ["f8:ba:7b:ae:f1:b4", "6b:2a:f5:d6:c3:49", 3],
    ["f8:ba:7b:ae:f1:b4", "7a:98:8f:a9:9c:72", 3],
]

# The expected forwarding port order of the switch
expected_res = [1, 2, 3, 0, 2, 3, 1, 3, 1, 2, 0, 1, 2]

assert len(mac_addrs) == ports_num
switch = Switch(env, ports_num, debug=True)
cables = [Cable(env, delay_dist=lambda: 10) for _ in range(ports_num)]
frame_generator = FrameGenerator(env, frames, ports_num, debug=True)

for i in range(ports_num):
    cables[i].set_endpoints(switch.ports[i], frame_generator.ports[i])

env.run(frame_generator.proc)

print("Switch forwarding order is correct: ", switch.log == expected_res)
