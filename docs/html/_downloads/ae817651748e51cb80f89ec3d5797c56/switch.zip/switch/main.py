from onl.sim import Environment
from onl.netdev import Wire
from framegenerator import FrameGenerator
from endpoint import Endpoint
from switch import Switch

env = Environment()

receiver_num = 4
mac_addrs = [
          "6b:2a:f5:d6:c3:49", 
          "7a:98:8f:a9:9c:72", 
          "4d:4a:5d:3d:bf:eb", 
          "f8:ba:7b:ae:f1:b4"
        ]

frames = [
        "6b:2a:f5:d6:c3:49",
        "6b:2a:f5:d6:c3:49",
        "7a:98:8f:a9:9c:72",
        "4d:4a:5d:3d:bf:eb",
        "f8:ba:7b:ae:f1:b4",
        "f8:ba:7b:ae:f1:b4",
        "7a:98:8f:a9:9c:72",
        "4d:4a:5d:3d:bf:eb",
        "6b:2a:f5:d6:c3:49"
        ]

expected_res = [
        0,1,2,3,
        0,
        0,1,2,3,
        0,1,2,3,
        0,1,2,3,
        3,
        1,
        2,
        0
      ]

assert len(mac_addrs) == receiver_num
receivers = [Endpoint(env, mac_addr, debug=True) for mac_addr in mac_addrs]
switch = Switch(env, receivers, debug=True)
wires = [Wire(env, delay_dist=lambda: 10) for _ in range(receiver_num * 2 + 1)]
frame_generator = FrameGenerator(env, frames, debug=True)

frame_generator.out = wires[0]
wires[0].out = switch
for i in range(receiver_num):
    wire1 = wires[1 + i]
    wire2 = wires[1 + receiver_num + i]
    receiver = receivers[i]
    switch.outs[i] = wire1
    wire1.out = receiver
    receiver.out = wire2
    wire2.out = switch

env.run(frame_generator.proc)

print(switch.log == expected_res)
