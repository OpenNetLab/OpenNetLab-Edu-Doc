from onl.sim import Environment
from onl.netdev import Wire, Cable
from framegenerator import FrameGenerator
from switch import Switch

env = Environment()

ports_num = 8
mac_addrs = ["a1", "a2", "a3", "a4", "a5", "a6", "a7", "a8"]

frames = [
    ["a1", "a8", 0],
    ["a8", "a7", 1],
    ["a1", "a8", 1],
    ["a1", "a8", 0],
    ["a2", "a7", 1],
    ["a7", "a2", 6],
    ["a3", "a7", 2],
    ["a4", "a8", 3],
    ["a5", "a7", 4],
    ["a5", "a7", 5]
]

expected_res = [1, 2, 3, 4, 5, 6, 7, 0, 2, 3, 4, 5, 6, 7, 1, 0, 2, 3, 4, 5, 6, 7, 1, 6, 0, 1, 2, 4, 5, 6, 7, 6, 0, 1, 2, 3, 4, 6, 7]

assert len(mac_addrs) == ports_num
switch = Switch(env, ports_num, debug=True)
cables = [Cable(env, delay_dist=lambda: 10) for _ in range(ports_num)]
frame_generator = FrameGenerator(env, frames, ports_num, debug=True)

for i in range(ports_num):
    cables[i].set_endpoints(switch.ports[i], frame_generator.ports[i])

env.run(frame_generator.proc)
print(switch.log)
print(switch.log == expected_res)
